from scipy.misc import imsave
from numpy import array as nparray
from numpy import dot, ones, fromfunction
from numpy.random import random as rndarray
from MLP import NeuralNet as net

def openFile(trainOrTest, labelOrImage):
	return open(trainOrTest+labelOrImage+".idx"+("3" if labelOrImage is "Images" else "1")+"-ubyte", "r+b")
	
def readInt(file, startPos, byteCount, inverted=True):
	file.seek(startPos)
	return 255-int.from_bytes(file.read(byteCount),"big") if inverted else int.from_bytes(file.read(byteCount),"big")
	
def readIntArray(file, startPos, byteCount, length, inverted=True):
	a = []
	while len(a)<length: 
		a.append(readInt(file, startPos, byteCount, inverted))
		startPos+=1
	return a

def readImage(trainBool, numImg, twoD=True, inverted=True):
	file = trif if trainBool else teif
	numImg=min(trainNum-1 if trainBool else testNum-1, max(0, numImg))
	imgStart = imgFileStart+(numImg)*imgW*imgH
	img = []
	while len(img)<(imgH if twoD else imgH*imgW):
		if twoD: img.append(readIntArray(file, imgStart, 1, imgW, inverted)) 
		else: img = img + readIntArray(file, imgStart, 1, imgW, inverted)
		imgStart+=imgW
	return nparray(img)/255.
	
def saveImageAsPng(numImg, trainBool=True, filename=None):
	if filename is None:filename = ("Tr" if trainBool else "Te") + "Image"+str(numImg)+".png"
	numImg=min(trainNum-1 if trainBool else testNum-1, max(0, numImg))
	imsave(filename, nparray(readImage(trainBool, numImg, inverted=True)))
	
def getImageArray(trainBool, start=0, size=None, twoD=False):
	a = []
	if size is None: size = trainNum if trainBool else testNum
	for i in range(start, start+size):
		a.append(readImage(trainBool, i, twoD, False))
	return nparray(a)
	
def getLabelArray(trainBool, start=0, size=None):
	a = []
	pos = lblFileStart+start
	if size is None: size = trainNum if trainBool else testNum
	file = trlf if trainBool else telf
	for i in range(start, start+size):
		a.append([readInt(file, pos, 1, False)])
		pos+=1
	return nparray(a)
	
def loadNetFromTxt(filename):
	file = open(filename)
	regBool = file.readline().strip() == "True"
	netShape = [int(i) for i in file.readline().split()]
	n = net(netShape[0], regBool)
	for i in range(len(netShape)-1):
		if i<len(netShape)-2: n.addLayer("MLP", netShape[i+1])
		else: n.addLayer("Class", netShape[i+1])
	currLayer = n.inLayer
	for i in range(len(netShape)-1):
		currWeights = []
		for j in range(netShape[i]+1):
			currWeights.append([float(k) for k in file.readline().split()])
		currLayer.weights = nparray(currWeights)
		currLayer = currLayer.nextLayer
	return n
	
def saveNetToTxt(filename, net):
	file = open(filename, "w")
	file.write(str(net.regBool) + "\n")
	netShape = str(net.inShape) + " "
	currLayer = net.inLayer
	while currLayer is not None:
		netShape+=str(currLayer.size) + " "
		currLayer = currLayer.nextLayer
	file.write(netShape + "\n")
	
	currLayer = net.inLayer
	while currLayer is not None:
		for row in currLayer.weights:
			string = ""
			for col in row: string+=str(col) + " "
			file.write(string + "\n")
		currLayer = currLayer.nextLayer
		
def saveNeuronToPng(net, layer=-1, num=0):
	if layer<0: layer = net.layerCount+layer
	if layer<0: raise Exception("The net does not have that many layers")
	filename = "LearnedImages/N"+str(layer)+"_"+str(num)+".png"
	image = rndarray(28*28)
	for i in range(60):
		net.inLayer.calculate(image)
		array = 1
		currLayer = net.inLayer
		while layer>0:
			array=dot(array, currLayer.actDerivative()*currLayer.weights[:-1])
			layer-=1
			currLayer = currLayer.nextLayer
		array = dot(array, currLayer.actDerivative()[num]*currLayer.weights[:-1,num]) if net.regBool else dot(array, currLayer.weights[:-1,num])
		image+=array
		image.clip(0, 1)
	image*=255
	imsave(filename, image.reshape(28,28))
		
trif = openFile("Train", "Images")
trlf = openFile("Train", "Labels")
teif = openFile("Test", "Images")
telf = openFile("Test", "Labels")
imgW = imgH = 28
imgFileStart = 16
lblFileStart = 8
trainNum = 60000
testNum = 10000