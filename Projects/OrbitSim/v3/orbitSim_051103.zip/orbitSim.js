//Author: Ivan Miloslavov

/*
Objects:
	Payloads w/ Orbits
	Climbers
	Earth
	Ribbon
Functions
	SimSystem functions
	Draw
*/

//Global variables
var canvas, ctx, centerX, centerY, scale;
var playing = false;
var totalTime = 0.0, lastTime, timeScale;
var climbers = [], payloads = [];
var activeClimber, activePayload;

//The Earth object
var earth = {
	G:6.67384e-11,
	MASS:5.97219e24,
	PERIOD:86164.1,
	MU:5.97219e24 * 6.67384e-11,
	OMEGA:2*Math.PI/86164.1,
	GEO_RADIUS:42164000,
	RADIUS:6378137,
	IMAGE:document.getElementById("earthPic"),
	draw:function() {
		ctx.drawImage(this.IMAGE,-this.RADIUS*scale,-this.RADIUS*scale,2*this.RADIUS*scale,2*this.RADIUS*scale);
	}
};

//The Elevator ribbon + GEO station and counterweight
var ribbon = {
	LENGTH:100000000,
	draw:function(){
		ctx.beginPath();
		ctx.lineWidth = 2;
		ctx.strokeStyle="#444444";
		ctx.moveTo(0,earth.RADIUS*scale);
		ctx.lineTo(0, (earth.RADIUS+this.LENGTH)*scale);
		ctx.stroke();
		ctx.beginPath();
		ctx.arc(0, earth.GEO_RADIUS*scale, 4,0,2*Math.PI);
		ctx.fillStyle="#4D3066";
		ctx.fill();
		ctx.beginPath();
		ctx.arc(0, (earth.RADIUS+this.LENGTH)*scale, 4,0,2*Math.PI);
		ctx.fillStyle="#22339F";
		ctx.fill();
	}
}

//The Climber class describes the climbers of the elevator
function Climber() {
	this.height = 0;
	this.payload = new Payload();
	this.active = true;
	payloads.push(this.payload);
}

Climber.prototype = {
	inactiveColor:"#AAAAAA",
	activeColor:"#FF0000",
	size:3,
	constructor:Climber,
	
	update:function() {
		
	},
	
	draw:function() {
		ctx.beginPath();
		if(this.active) {ctx.fillStyle=this.activeColor;}
		else {ctx.fillStyle=this.inactiveColor;}
		ctx.fillRect(-this.size, earth.RADIUS*scale-this.size, 2*this.size, 2*this.size);
	}
}

//The Payload class describes the payloads that climbers deliver to orbit
function Payload() {
	this.height = 0;
	this.released = false;
	this.active = true;
}

Payload.prototype = {
	inactiveColor:"#00FFFF",
	activeColor:"#FFFF00",
	constructor:Payload,
	
	update:function() {
		
	},
	
	draw:function(angle) {
		ctx.beginPath();
		if(!this.released) {
			ctx.rotate(angle);
			ctx.arc(0, (earth.RADIUS+this.height)*scale, 2,0,2*Math.PI);
			if(this.active) {ctx.fillStyle=this.activeColor;}
			else {ctx.fillStyle=this.inactiveColor;}
			ctx.fill();
			ctx.rotate(-angle);
		}
	}
}

//Initializes some variables and calls the update function
function start() {
	canvas = document.getElementById("animPane");
	ctx = canvas.getContext("2d");
	centerX = canvas.width/2;
	centerY = canvas.height/2;
	scale = Math.min(centerX, centerY)/150000000.0;
	lastTime = Date.now();
	timeScale = earth.PERIOD/4800;
	update();
}

//Called at every frame, this function updates all the locations and calls for redraw
function update() {
	window.requestAnimationFrame(update);
	var currTime = Date.now();
	if(playing) {
		for(var i = 0; i<climbers.length; i++) {
			climbers[i].update();
		}
		for(var i = 0; i<payloads.length; i++) {
			payloads[i].update();
		}
		draw();
		totalTime += (currTime-lastTime)*timeScale;
		document.getElementById("simTotalTime").innerHTML = (totalTime/earth.PERIOD).toFixed(2);
	}
	lastTime = currTime;
}

//Called by update(), redraws the scene at every frame
function draw() {
	ctx.drawImage(document.getElementById("bgPic"), 0, 0, 2*centerX, 2*centerY);
	ctx.translate(centerX, centerY);
	var angle = totalTime/earth.PERIOD*Math.PI*2;
	ctx.rotate(angle);
	earth.draw();
	ribbon.draw();
	for(var i = 0; i<climbers.length; i++) {
		climbers[i].draw();
	}
	ctx.rotate(-angle);
	for(var i = 0; i<payloads.length; i++) {
		payloads[i].draw(angle);
	}
	ctx.translate(-centerX, -centerY);
}

//Called by the New Climber button, creates a new Climber with a Payload in italics
function createClimber() {
	climbers.push(new Climber());
	document.getElementById("climberSendInput").hidden = false;
	document.getElementById("climberSendInput").children[0].max = climbers.length;
	document.getElementById("climberSendInput").children[0].value = climbers.length;
}

//Called by the Play/Pause button, toggles the button and the running of the simulation
function playPause(button) {
	if(button.innerHTML == "Play") {
		button.innerHTML = "Pause";
		playing = true;
	} else {
		button.innerHTML = "Play";
		playing = false;
	}
}

//Called by the simSpeed field, changes the speed of the simulation
function updateTimeScale(input) {
	if(input.value>15) input.value = 15;
	if(input.value<1) input.value = 1;
	timeScale = earth.PERIOD/24000*input.value;
}

//Called by a change in climber numbers, changes the selection of climbers
function updateClimberChoice(input) {
	activeClimber = climbers[input.value-1];
}

start();