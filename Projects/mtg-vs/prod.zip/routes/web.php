<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

use Illuminate\Http\Request;

$router->get('/', function () {
	$votecount = app('db')->table('matchups')->count();
    return view('welcome', compact('votecount'));
});

$router->get('/vote', function () {
    return view('matchup');
});

$router->get('/vote/new', 'VoteController@generate');

$router->post('/vote', 'VoteController@save_vote');

$router->get('/card/random', function() {
	$card = app('db')->table('cards')->inRandomOrder()->value('scryfall_id');
	return redirect()->route('card', ['id' => $card]);
});

$router->get('/card/named', function(Request $request) {
	$name = $request->input('name');

	// Check if name is exact in our database
	$query = app('db')->table('cards')->where('name', $name);
	if($query->count() > 0) {
		$card = $query->value('scryfall_id');
		return redirect()->route('card', ['id' => $card]);
	} else {
		return redirect()->route('card', ['id' => $name]);
	}
});

$router->get('/card/name_of/{id}', ['as' => 'name_of_card', function($id) {
	return name_from_id($id);
}]);

$router->get('/card/{id}', ['as' => 'card', function($id) {
	$card = app('db')->table('cards')->where('scryfall_id', $id)->first()
			?? $id;
	$matchups = app('db')->table('matchups')
						 ->where('winner', $id)
						 ->orWhere('loser', $id)
						 ->get(['winner', 'loser', 'voted_at']);
	return view('card', compact('card', 'matchups'));
}]);

$router->get('user', function() {
	$name = "";
	$matchups = app('db')->table('matchups')->where('voter', $name)->get(['winner', 'loser', 'ordered', 'voted_at']);
	return view('user', compact('name', 'matchups'));
});

$router->get('/user/{name}', ['as' => 'user', function($name) {
	$matchups = app('db')->table('matchups')->where('voter', $name)->get(['winner', 'loser', 'ordered', 'voted_at']);
	return view('user', compact('name', 'matchups'));
}]);

$router->get('/image/{id}', ['as' => 'image', function($id) {
	return redirect()->to(get_image_link($id));
}]);

$router->get('/version', function () use ($router) {
    return $router->app->version();
});