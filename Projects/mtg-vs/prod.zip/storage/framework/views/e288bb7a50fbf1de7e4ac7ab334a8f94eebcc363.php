

<?php
$has_card = !is_string($card);
?>

<?php $__env->startSection('title', $has_card ? $card->name : "Card not found"); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
	<form class="form-inline" action="/card/named" method="get">
		<div class="form-row my-2 w-100">
			<div class="col-md-9">
				<input type="text" class="form-control mb-2 mr-sm-2 w-100" name="name" placeholder="Card name or Scryfall ID" autocomplete="off" />
			</div>
			<div class="col-md-3">
				<button type="submit" class="btn btn-primary mb-2">Search</button>
				<a class="btn btn-warning mb-2 float-right" href="/card/random">Random</a>
			</div>
		</div>
	</form>

	<?php if($has_card): ?>
	<div class="row">
		<div class="col-8 offset-2 col-md-6 offset-md-0">

			<img class="img-fluid" src="<?php echo e(route('image', ['id' => $card->scryfall_id])); ?>" />
		</div>
		<div class="col-md-6">
			<div class="text-center display-3 border border-primary rounded-pill my-2" style="background-color: lavender">
				<span class="text-success">
					<?php echo e($matchups->where('winner', $card->scryfall_id)->count()); ?>W
				</span>
				 - 
				<span class="text-danger">
					<?php echo e($matchups->where('loser', $card->scryfall_id)->count()); ?>L
				</span>
			</div>
			<ul class="list-group list-group-flush">
				<?php $__currentLoopData = $matchups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matchup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php 
					$won = $matchup->winner == $card->scryfall_id;
					$opponent = $won ? $matchup->loser : $matchup->winner;
				?>
				<li class="list-group-item <?php echo e($won ? "list-group-item-success" : "list-group-item-danger"); ?>">
    				<div class="d-flex w-100 justify-content-between">
    					<span>
							<?php echo e($won ? "W" : "L"); ?> vs 
							<a class="font-weight-bold text-reset" href="<?php echo e(route('card', ['id' => $opponent])); ?>">
								<?php echo e(name_from_id($opponent)); ?>

							</a>
						</span>
						<small>
							<?php echo e($matchup->voted_at); ?>

						</small>
					</div>
				</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
	</div>
	<?php else: ?>
	<p> A card with this ID or name was not found! </p>
	<?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ivan M\Desktop\CODING\Personal\Projects\mtg-vs\resources\views/card.blade.php ENDPATH**/ ?>