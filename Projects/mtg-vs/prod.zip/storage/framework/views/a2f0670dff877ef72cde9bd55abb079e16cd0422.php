

<?php $__env->startSection('title', "User $name"); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

	<div class="form-row my-2 justify-content-center">
		<input type="text" class="form-control mb-2 mr-sm-2 w-25" placeholder="Username" id="username" autocomplete="off" />
		<a id="submit" class="btn btn-primary mb-2" href="/user">Search</a>
	</div>

	<h2 class="display-4 text-center"><?php echo e($name ? $name . "'s votes" : "Votes without username"); ?></h2>

	<ul class="list-group">
		<?php $__currentLoopData = $matchups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matchup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php 
			if($matchup->ordered) {
				$leftside = $matchup->winner;
				$rightside = $matchup->loser;
			} else {
				$leftside = $matchup->loser;
				$rightside = $matchup->winner;
			}
		?>
		<li class="list-group-item">
			<div class="d-flex w-100 justify-content-between">
				<span>
					<a class="<?php echo e($matchup->ordered ? "font-weight-bold" : ""); ?> text-reset" href="<?php echo e(route('card', ['id' => $leftside])); ?>">
						<?php echo e(name_from_id($leftside)); ?>

					</a>
					 vs 
					<a class="<?php echo e($matchup->ordered ? "" : "font-weight-bold"); ?> text-reset" href="<?php echo e(route('card', ['id' => $rightside])); ?>">
						<?php echo e(name_from_id($rightside)); ?>

					</a>
				</span>
				<small>
					<?php echo e($matchup->voted_at); ?>

				</small>
			</div>
		</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
	$("#username").change(() => {
		$("#submit").attr('href', '/user/' + $("#username").val());
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ivan M\Desktop\CODING\Personal\Projects\mtg-vs\resources\views/user.blade.php ENDPATH**/ ?>